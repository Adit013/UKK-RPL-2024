<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=">
    <title>Tampilan Index</title>
</head>
<body>
    <h1>Tampilan Index</h1>
    <ul>
        <li><a href="login.php">login</li>
        <li><a href="register.php">Register</li>
    </ul>
    
</body>
</html>